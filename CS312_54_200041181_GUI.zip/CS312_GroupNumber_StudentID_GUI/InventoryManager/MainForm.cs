namespace InventoryManager;

/// <summary>
/// Main window. All controls (tab control, tab pages and the six screens) are created in MainForm.Designer.cs
/// and are editable in the Visual Studio Designer. Each screen loads its own data when it is first shown.
/// </summary>
public partial class MainForm : Form
{
    public MainForm()
    {
        InitializeComponent();
    }
}
